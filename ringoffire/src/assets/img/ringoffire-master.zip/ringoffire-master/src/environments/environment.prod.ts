export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAKr3hFglKk-IgKD9Z2ElfEbU3RnXOLc7s",
    authDomain: "ring-of-fire-2d38a.firebaseapp.com",
    databaseURL: "https://ring-of-fire-2d38a.firebaseio.com",
    projectId: "ring-of-fire-2d38a",
    storageBucket: "ring-of-fire-2d38a.appspot.com",
    messagingSenderId: "843114632066",
    appId: "1:843114632066:web:f6440923ec59c83121f59b"
  }
};
